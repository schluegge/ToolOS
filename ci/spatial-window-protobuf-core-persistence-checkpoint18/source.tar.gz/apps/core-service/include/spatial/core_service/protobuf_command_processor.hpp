#pragma once

#include <spatial/common/result.hpp>
#include <spatial/core_service/core_service.hpp>

#include <cstddef>
#include <cstdint>
#include <span>
#include <string>
#include <vector>

namespace spatial::service {

enum class CommandProcessorErrorCode {
    invalid_configuration,
    request_decode_failed,
    response_encode_failed,
    canonical_state_failure,
};

struct CommandProcessorError final {
    CommandProcessorErrorCode code{CommandProcessorErrorCode::request_decode_failed};
    std::string message;
};

using CommandProcessorResult =
    spatial::common::Result<std::vector<std::byte>, CommandProcessorError>;

[[nodiscard]] CommandProcessorResult process_transform_commit_envelope(
    std::span<const std::byte> payload,
    const AuthenticatedConnection& connection,
    CoreService& core,
    spatial::domain::Uuid core_instance_id,
    std::uint64_t response_request_id);

}  // namespace spatial::service
