#pragma once

#include <spatial/common/result.hpp>
#include <spatial/core/mutation.hpp>
#include <spatial/core/session_state.hpp>
#include <spatial/domain/types.hpp>
#include <spatial/persistence/mutation_repository.hpp>

#include <filesystem>
#include <map>
#include <memory>
#include <string>
#include <thread>
#include <vector>

namespace spatial::service {

enum class ProcessRole {
    qt_client,
    renderer_host,
    plugin_broker,
    unknown,
};

struct AuthenticatedConnection final {
    spatial::domain::Uuid connection_id;
    spatial::domain::Uuid instance_id;
    spatial::domain::Uuid core_session_epoch;
    ProcessRole role{ProcessRole::unknown};
    bool authenticated{};
};

struct CreateWindowSurfaceCommand final {
    spatial::domain::Uuid command_id;
    spatial::domain::Uuid surface_id;
    spatial::domain::Uuid scene_node_id;
    spatial::domain::Uuid window_binding_id;
    spatial::domain::Uuid capture_binding_id;
    spatial::domain::Uuid input_binding_id;
    spatial::domain::Uuid native_window_id;
    spatial::domain::Revision expected_revision{};
};

struct CommitSurfaceTransformCommand final {
    spatial::domain::Uuid command_id;
    spatial::domain::Uuid surface_id;
    spatial::domain::Transform transform;
    spatial::domain::Revision expected_revision{};
};

struct CanonicalSurfaceState final {
    spatial::domain::Uuid surface_id;
    spatial::domain::Uuid scene_node_id;
    spatial::domain::Transform transform;
    spatial::domain::Revision surface_revision{};
    spatial::domain::Revision transform_revision{};
};

struct CommandAcknowledgement final {
    spatial::domain::Uuid command_id;
    spatial::domain::Uuid entity_id;
    spatial::domain::Revision applied_revision{};
    bool deduplicated{};
};

class CommandDelivery {
public:
    virtual ~CommandDelivery() = default;
    [[nodiscard]] virtual bool publish_delta(const spatial::core::StateDelta& delta) = 0;
    [[nodiscard]] virtual bool acknowledge(const CommandAcknowledgement& acknowledgement) = 0;
};

enum class CoreErrorCode {
    invalid_configuration,
    not_running,
    owner_thread_violation,
    unauthorized,
    stale_epoch,
    stale_expected_revision,
    invalid_command,
    persistence_failure,
    journal_failure,
    delivery_failed,
    invalid_reconnect_revision,
    surface_not_found,
};

struct CoreError final {
    CoreErrorCode code{CoreErrorCode::invalid_command};
    std::string message;
};

struct CoreConfig final {
    std::filesystem::path database_path;
    spatial::domain::Uuid core_session_epoch;
    spatial::persistence::RepositoryOptions persistence_options{};
};

struct ReconnectResult final {
    spatial::domain::Revision canonical_revision{};
    bool snapshot_required{};
    std::vector<spatial::core::StateDelta> deltas;
};

class CoreService final {
public:
    using StartResult = spatial::common::Result<std::unique_ptr<CoreService>, CoreError>;
    using CommandResult = spatial::common::Result<CommandAcknowledgement, CoreError>;
    using ReconnectStateResult = spatial::common::Result<ReconnectResult, CoreError>;
    using BoolResult = spatial::common::Result<bool, CoreError>;
    using SurfaceStateResult = spatial::common::Result<CanonicalSurfaceState, CoreError>;
    using SurfaceStatesResult = spatial::common::Result<std::vector<CanonicalSurfaceState>, CoreError>;

    [[nodiscard]] static StartResult start(CoreConfig config);

    CoreService(const CoreService&) = delete;
    CoreService& operator=(const CoreService&) = delete;
    ~CoreService();

    [[nodiscard]] CommandResult handle_create_window_surface(
        const AuthenticatedConnection& connection,
        const CreateWindowSurfaceCommand& command,
        CommandDelivery& delivery);
    [[nodiscard]] CommandResult handle_commit_surface_transform(
        const AuthenticatedConnection& connection,
        const CommitSurfaceTransformCommand& command,
        CommandDelivery& delivery);
    [[nodiscard]] ReconnectStateResult reconnect(
        const AuthenticatedConnection& connection,
        spatial::domain::Revision last_seen_revision) const;
    [[nodiscard]] BoolResult surface_exists(spatial::domain::Uuid surface_id) const;
    [[nodiscard]] SurfaceStateResult canonical_surface_state(spatial::domain::Uuid surface_id) const;
    [[nodiscard]] SurfaceStatesResult canonical_surface_states() const;
    [[nodiscard]] bool canonical_surface_exists(spatial::domain::Uuid surface_id) const;
    [[nodiscard]] spatial::domain::Revision canonical_revision() const noexcept { return canonical_revision_; }
    void stop() noexcept;

private:
    CoreService(
        std::unique_ptr<spatial::persistence::MutationRepository> repository,
        spatial::domain::Uuid core_session_epoch,
        spatial::domain::Revision canonical_revision,
        std::vector<spatial::persistence::DurableSurfaceState> surface_states);

    [[nodiscard]] spatial::common::Result<void, CoreError> require_owner() const;
    [[nodiscard]] spatial::common::Result<void, CoreError> authorize(
        const AuthenticatedConnection& connection) const;

    std::unique_ptr<spatial::persistence::MutationRepository> repository_;
    spatial::domain::Uuid core_session_epoch_;
    spatial::domain::Revision canonical_revision_{};
    std::map<std::string, CanonicalSurfaceState> canonical_surfaces_;
    spatial::core::DeltaJournal delta_journal_{};
    std::thread::id owner_thread_;
};

}  // namespace spatial::service
