#include <spatial/core_service/core_service.hpp>

#include "command_dispatcher.hpp"

#include <utility>

namespace spatial::service {
namespace {

[[nodiscard]] CoreError persistence_error(const spatial::persistence::PersistenceError& error) {
    return CoreError{
        CoreErrorCode::persistence_failure,
        "persistence operation failed: " + error.message,
    };
}

[[nodiscard]] CommandAcknowledgement make_acknowledgement(
    const spatial::domain::Uuid& command_id,
    const spatial::domain::Uuid& entity_id,
    const spatial::core::CommittedMutation& mutation) {
    return CommandAcknowledgement{
        .command_id = command_id,
        .entity_id = entity_id,
        .applied_revision = mutation.revision,
        .deduplicated = mutation.deduplicated,
    };
}

}  // namespace

CoreService::CoreService(
    std::unique_ptr<spatial::persistence::MutationRepository> repository,
    spatial::domain::Uuid core_session_epoch,
    spatial::domain::Revision canonical_revision,
    std::vector<spatial::persistence::DurableSurfaceState> surface_states)
    : repository_(std::move(repository)),
      core_session_epoch_(core_session_epoch),
      canonical_revision_(canonical_revision),
      owner_thread_(std::this_thread::get_id()) {
    for (const auto& state : surface_states) {
        canonical_surfaces_.emplace(
            state.surface_id.to_string(),
            CanonicalSurfaceState{
                .surface_id = state.surface_id,
                .scene_node_id = state.scene_node_id,
                .transform = state.transform,
                .surface_revision = state.surface_revision,
                .transform_revision = state.transform_revision,
            });
    }
}

CoreService::~CoreService() {
    stop();
}

CoreService::StartResult CoreService::start(CoreConfig config) {
    if (config.database_path.empty() || config.core_session_epoch.is_nil()) {
        return StartResult::failure(CoreError{
            CoreErrorCode::invalid_configuration,
            "Core Service requires a database path and non-nil session epoch",
        });
    }

    auto opened = spatial::persistence::MutationRepository::open(
        config.database_path,
        config.persistence_options);
    if (!opened.has_value()) {
        return StartResult::failure(persistence_error(opened.error()));
    }

    auto repository = std::move(opened.value());
    const auto revision = repository->current_revision().get();
    if (!revision.has_value()) {
        return StartResult::failure(persistence_error(revision.error()));
    }
    auto surface_states = repository->list_surface_states().get();
    if (!surface_states.has_value()) {
        return StartResult::failure(persistence_error(surface_states.error()));
    }

    return StartResult::success(std::unique_ptr<CoreService>(new CoreService(
        std::move(repository),
        config.core_session_epoch,
        revision.value(),
        std::move(surface_states.value()))));
}

spatial::common::Result<void, CoreError> CoreService::require_owner() const {
    if (std::this_thread::get_id() != owner_thread_) {
        return spatial::common::Result<void, CoreError>::failure(CoreError{
            CoreErrorCode::owner_thread_violation,
            "Core Service command state is owned by its startup thread",
        });
    }
    if (repository_ == nullptr) {
        return spatial::common::Result<void, CoreError>::failure(CoreError{
            CoreErrorCode::not_running,
            "Core Service is stopped",
        });
    }
    return spatial::common::Result<void, CoreError>::success();
}

spatial::common::Result<void, CoreError> CoreService::authorize(
    const AuthenticatedConnection& connection) const {
    if (!connection.authenticated || connection.connection_id.is_nil() || connection.instance_id.is_nil() ||
        connection.role != ProcessRole::qt_client) {
        return spatial::common::Result<void, CoreError>::failure(CoreError{
            CoreErrorCode::unauthorized,
            "connection is not an authenticated command-capable Qt client",
        });
    }
    const auto epoch = spatial::core::validate_session_epoch(core_session_epoch_, connection.core_session_epoch);
    if (!epoch.has_value()) {
        return spatial::common::Result<void, CoreError>::failure(CoreError{
            CoreErrorCode::stale_epoch,
            epoch.error().message,
        });
    }
    return spatial::common::Result<void, CoreError>::success();
}

CoreService::CommandResult CoreService::handle_create_window_surface(
    const AuthenticatedConnection& connection,
    const CreateWindowSurfaceCommand& command,
    CommandDelivery& delivery) {
    const auto owner = require_owner();
    if (!owner.has_value()) {
        return CommandResult::failure(owner.error());
    }
    const auto authorization = authorize(connection);
    if (!authorization.has_value()) {
        return CommandResult::failure(authorization.error());
    }
    if (command.expected_revision != canonical_revision_) {
        return CommandResult::failure(CoreError{
            CoreErrorCode::stale_expected_revision,
            "command expected revision does not match current canonical revision",
        });
    }

    auto translated = detail::validate_and_translate(command);
    if (!translated.has_value()) {
        return CommandResult::failure(translated.error());
    }

    const auto committed = repository_->commit(std::move(translated.value())).get();
    if (!committed.has_value()) {
        return CommandResult::failure(persistence_error(committed.error()));
    }

    const auto& mutation = committed.value();
    if (!mutation.deduplicated) {
        if (mutation.delta.previous_revision != canonical_revision_ ||
            mutation.revision != mutation.delta.state_revision) {
            return CommandResult::failure(CoreError{
                CoreErrorCode::journal_failure,
                "committed mutation does not continue the canonical in-memory revision",
            });
        }

        canonical_revision_ = mutation.revision;
        canonical_surfaces_.insert_or_assign(
            command.surface_id.to_string(),
            CanonicalSurfaceState{
                .surface_id = command.surface_id,
                .scene_node_id = command.scene_node_id,
                .transform = {},
                .surface_revision = mutation.revision,
                .transform_revision = mutation.revision,
            });
        const auto journaled = delta_journal_.append(mutation.delta);
        if (!journaled.has_value()) {
            return CommandResult::failure(CoreError{
                CoreErrorCode::journal_failure,
                "durable mutation could not be retained for reconnect: " + journaled.error().message,
            });
        }
        if (!delivery.publish_delta(mutation.delta)) {
            return CommandResult::failure(CoreError{
                CoreErrorCode::delivery_failed,
                "connection closed after durable commit while publishing the state delta",
            });
        }
    }

    const auto acknowledgement = make_acknowledgement(command.command_id, command.surface_id, mutation);
    if (!delivery.acknowledge(acknowledgement)) {
        return CommandResult::failure(CoreError{
            CoreErrorCode::delivery_failed,
            "connection closed after durable commit before acknowledgement delivery",
        });
    }
    return CommandResult::success(acknowledgement);
}

CoreService::CommandResult CoreService::handle_commit_surface_transform(
    const AuthenticatedConnection& connection,
    const CommitSurfaceTransformCommand& command,
    CommandDelivery& delivery) {
    const auto owner = require_owner();
    if (!owner.has_value()) {
        return CommandResult::failure(owner.error());
    }
    const auto authorization = authorize(connection);
    if (!authorization.has_value()) {
        return CommandResult::failure(authorization.error());
    }
    if (command.expected_revision != canonical_revision_) {
        return CommandResult::failure(CoreError{
            CoreErrorCode::stale_expected_revision,
            "command expected revision does not match current canonical revision",
        });
    }

    const auto existing = canonical_surfaces_.find(command.surface_id.to_string());
    if (existing == canonical_surfaces_.end()) {
        return CommandResult::failure(CoreError{
            CoreErrorCode::surface_not_found,
            "surface transform target does not exist",
        });
    }

    auto translated = detail::validate_and_translate(command);
    if (!translated.has_value()) {
        return CommandResult::failure(translated.error());
    }

    const auto committed = repository_->commit(std::move(translated.value())).get();
    if (!committed.has_value()) {
        return CommandResult::failure(persistence_error(committed.error()));
    }

    const auto& mutation = committed.value();
    if (!mutation.deduplicated) {
        if (mutation.delta.previous_revision != canonical_revision_ ||
            mutation.revision != mutation.delta.state_revision) {
            return CommandResult::failure(CoreError{
                CoreErrorCode::journal_failure,
                "committed transform does not continue the canonical in-memory revision",
            });
        }

        canonical_revision_ = mutation.revision;
        auto& canonical = existing->second;
        canonical.transform = command.transform;
        canonical.transform_revision = mutation.revision;
        const auto journaled = delta_journal_.append(mutation.delta);
        if (!journaled.has_value()) {
            return CommandResult::failure(CoreError{
                CoreErrorCode::journal_failure,
                "durable transform could not be retained for reconnect: " + journaled.error().message,
            });
        }
        if (!delivery.publish_delta(mutation.delta)) {
            return CommandResult::failure(CoreError{
                CoreErrorCode::delivery_failed,
                "connection closed after durable transform commit while publishing the state delta",
            });
        }
    }

    const auto acknowledgement = make_acknowledgement(command.command_id, command.surface_id, mutation);
    if (!delivery.acknowledge(acknowledgement)) {
        return CommandResult::failure(CoreError{
            CoreErrorCode::delivery_failed,
            "connection closed after durable transform commit before acknowledgement delivery",
        });
    }
    return CommandResult::success(acknowledgement);
}

CoreService::ReconnectStateResult CoreService::reconnect(
    const AuthenticatedConnection& connection,
    spatial::domain::Revision last_seen_revision) const {
    const auto owner = require_owner();
    if (!owner.has_value()) {
        return ReconnectStateResult::failure(owner.error());
    }
    const auto authorization = authorize(connection);
    if (!authorization.has_value()) {
        return ReconnectStateResult::failure(authorization.error());
    }
    if (last_seen_revision > canonical_revision_) {
        return ReconnectStateResult::failure(CoreError{
            CoreErrorCode::invalid_reconnect_revision,
            "client last-seen revision is newer than current canonical state",
        });
    }
    if (last_seen_revision == canonical_revision_) {
        return ReconnectStateResult::success(ReconnectResult{
            .canonical_revision = canonical_revision_,
            .snapshot_required = false,
            .deltas = {},
        });
    }

    auto replay = delta_journal_.replay_from(last_seen_revision);
    if (!replay.has_value() || replay->empty() || replay->back().state_revision != canonical_revision_) {
        return ReconnectStateResult::success(ReconnectResult{
            .canonical_revision = canonical_revision_,
            .snapshot_required = true,
            .deltas = {},
        });
    }
    return ReconnectStateResult::success(ReconnectResult{
        .canonical_revision = canonical_revision_,
        .snapshot_required = false,
        .deltas = std::move(*replay),
    });
}

CoreService::BoolResult CoreService::surface_exists(spatial::domain::Uuid surface_id) const {
    const auto owner = require_owner();
    if (!owner.has_value()) {
        return BoolResult::failure(owner.error());
    }
    const auto result = repository_->surface_exists(surface_id).get();
    if (!result.has_value()) {
        return BoolResult::failure(persistence_error(result.error()));
    }
    return BoolResult::success(result.value());
}

CoreService::SurfaceStateResult CoreService::canonical_surface_state(spatial::domain::Uuid surface_id) const {
    const auto owner = require_owner();
    if (!owner.has_value()) {
        return SurfaceStateResult::failure(owner.error());
    }
    const auto state = canonical_surfaces_.find(surface_id.to_string());
    if (state == canonical_surfaces_.end()) {
        return SurfaceStateResult::failure(CoreError{
            CoreErrorCode::surface_not_found,
            "canonical surface does not exist",
        });
    }
    return SurfaceStateResult::success(state->second);
}

CoreService::SurfaceStatesResult CoreService::canonical_surface_states() const {
    const auto owner = require_owner();
    if (!owner.has_value()) {
        return SurfaceStatesResult::failure(owner.error());
    }
    std::vector<CanonicalSurfaceState> states;
    states.reserve(canonical_surfaces_.size());
    for (const auto& [identity, state] : canonical_surfaces_) {
        static_cast<void>(identity);
        states.push_back(state);
    }
    return SurfaceStatesResult::success(std::move(states));
}

bool CoreService::canonical_surface_exists(spatial::domain::Uuid surface_id) const {
    return canonical_surfaces_.contains(surface_id.to_string());
}

void CoreService::stop() noexcept {
    if (repository_ != nullptr) {
        repository_.reset();
    }
}

}  // namespace spatial::service
