#include <spatial/core_service/core_service.hpp>

#include <iostream>
#include <string>

int main(int argc, char** argv) {
    if (argc != 3) {
        std::cerr << "usage: spatial-core-service <database-path> <core-session-epoch>\n";
        return 2;
    }
    const auto epoch = spatial::common::Uuid::parse(argv[2]);
    if (!epoch.has_value() || epoch->is_nil()) {
        std::cerr << "invalid non-nil Core session epoch\n";
        return 2;
    }
    auto service = spatial::service::CoreService::start({
        .database_path = argv[1],
        .core_session_epoch = *epoch,
    });
    if (!service.has_value()) {
        std::cerr << service.error().message << '\n';
        return 1;
    }
    std::cout << "core-service-ready revision=" << service.value()->canonical_revision() << '\n';
    std::string command;
    while (std::getline(std::cin, command)) {
        if (command == "shutdown") {
            break;
        }
        std::cerr << "unsupported local control command\n";
    }
    service.value()->stop();
    return 0;
}
