#pragma once

#include <spatial/common/result.hpp>
#include <spatial/core/mutation.hpp>
#include <spatial/core_service/core_service.hpp>

namespace spatial::service::detail {

[[nodiscard]] spatial::common::Result<spatial::core::Mutation, CoreError> validate_and_translate(
    const CreateWindowSurfaceCommand& command);
[[nodiscard]] spatial::common::Result<spatial::core::Mutation, CoreError> validate_and_translate(
    const CommitSurfaceTransformCommand& command);

}  // namespace spatial::service::detail
