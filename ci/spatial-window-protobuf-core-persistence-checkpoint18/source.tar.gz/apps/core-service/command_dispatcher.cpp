#include "command_dispatcher.hpp"

#include <utility>

namespace spatial::service::detail {

spatial::common::Result<spatial::core::Mutation, CoreError> validate_and_translate(
    const CreateWindowSurfaceCommand& command) {
    spatial::core::Mutation mutation = spatial::core::CreateWindowSurfaceMutation{
        .command_id = command.command_id,
        .surface_id = command.surface_id,
        .scene_node_id = command.scene_node_id,
        .window_binding_id = command.window_binding_id,
        .capture_binding_id = command.capture_binding_id,
        .input_binding_id = command.input_binding_id,
        .native_window_id = command.native_window_id,
    };
    if (!spatial::core::valid(mutation)) {
        return spatial::common::Result<spatial::core::Mutation, CoreError>::failure(CoreError{
            CoreErrorCode::invalid_command,
            "CreateWindowSurface contains a nil required UUID",
        });
    }
    return spatial::common::Result<spatial::core::Mutation, CoreError>::success(std::move(mutation));
}

spatial::common::Result<spatial::core::Mutation, CoreError> validate_and_translate(
    const CommitSurfaceTransformCommand& command) {
    spatial::core::Mutation mutation = spatial::core::CommitSurfaceTransformMutation{
        .command_id = command.command_id,
        .surface_id = command.surface_id,
        .transform = command.transform,
    };
    if (!spatial::core::valid(mutation)) {
        return spatial::common::Result<spatial::core::Mutation, CoreError>::failure(CoreError{
            CoreErrorCode::invalid_command,
            "CommitSurfaceTransform contains an invalid UUID or transform",
        });
    }
    return spatial::common::Result<spatial::core::Mutation, CoreError>::success(std::move(mutation));
}

}  // namespace spatial::service::detail
