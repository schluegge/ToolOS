#include <spatial/core_service/protobuf_command_processor.hpp>

#include <spatial/protocol/transform_command_codec.hpp>

#include <string_view>
#include <utility>

namespace spatial::service {
namespace {

class CapturingDelivery final : public CommandDelivery {
public:
    bool publish_delta(const spatial::core::StateDelta& delta) override {
        delta_ = delta;
        published_ = true;
        return true;
    }

    bool acknowledge(const CommandAcknowledgement& acknowledgement) override {
        acknowledgement_ = acknowledgement;
        acknowledged_ = true;
        return true;
    }

    [[nodiscard]] bool published() const noexcept { return published_; }
    [[nodiscard]] bool acknowledged() const noexcept { return acknowledged_; }
    [[nodiscard]] const CommandAcknowledgement& acknowledgement() const noexcept {
        return acknowledgement_;
    }

private:
    spatial::core::StateDelta delta_{};
    CommandAcknowledgement acknowledgement_{};
    bool published_{};
    bool acknowledged_{};
};

struct WireFailure final {
    std::string_view code;
    bool retryable{};
    std::string_view summary;
};

[[nodiscard]] WireFailure map_core_error(CoreErrorCode code) noexcept {
    switch (code) {
        case CoreErrorCode::stale_expected_revision:
            return {"STALE_EXPECTED_REVISION", true, "Refresh canonical state and retry."};
        case CoreErrorCode::surface_not_found:
            return {"SURFACE_NOT_FOUND", false, "The target surface no longer exists."};
        case CoreErrorCode::invalid_command:
            return {"INVALID_TRANSFORM_COMMAND", false, "The transform command is invalid."};
        case CoreErrorCode::unauthorized:
            return {"UNAUTHORIZED_COMMAND", false, "The connection is not authorized for this command."};
        case CoreErrorCode::stale_epoch:
            return {"STALE_SESSION_EPOCH", true, "Reconnect to the current Core session."};
        case CoreErrorCode::persistence_failure:
            return {"PERSISTENCE_COMMIT_FAILED", true, "The transform could not be committed durably."};
        case CoreErrorCode::not_running:
        case CoreErrorCode::owner_thread_violation:
            return {"CORE_UNAVAILABLE", true, "The Core Service is temporarily unavailable."};
        case CoreErrorCode::journal_failure:
        case CoreErrorCode::delivery_failed:
            return {"CORE_STATE_DELIVERY_FAILED", true, "The durable state changed but delivery did not complete."};
        case CoreErrorCode::invalid_configuration:
        case CoreErrorCode::invalid_reconnect_revision:
            return {"CORE_COMMAND_REJECTED", false, "The Core Service rejected the command."};
    }
    return {"CORE_COMMAND_REJECTED", false, "The Core Service rejected the command."};
}

[[nodiscard]] CommandProcessorResult processor_failure(
    CommandProcessorErrorCode code,
    std::string message) {
    return CommandProcessorResult::failure(CommandProcessorError{code, std::move(message)});
}

[[nodiscard]] CommandProcessorResult encode_failure(
    const spatial::protocol::TransformCommitRequest& request,
    const CoreService& core,
    spatial::domain::Uuid core_instance_id,
    std::uint64_t response_request_id,
    WireFailure failure) {
    const spatial::protocol::CommandFailure response{
        .envelope = {
            .request_id = response_request_id,
            .correlation_id = request.envelope.request_id,
            .sender_instance_id = core_instance_id,
            .core_session_epoch = request.envelope.core_session_epoch,
            .state_revision = core.canonical_revision(),
        },
        .error_code = std::string(failure.code),
        .retryable = failure.retryable,
        .safe_user_summary = std::string(failure.summary),
    };
    auto encoded = spatial::protocol::encode_command_failure(response);
    if (!encoded.has_value()) {
        return processor_failure(
            CommandProcessorErrorCode::response_encode_failed,
            "failed to encode structured command failure: " + encoded.error().message);
    }
    return CommandProcessorResult::success(std::move(encoded.value()));
}

}  // namespace

CommandProcessorResult process_transform_commit_envelope(
    std::span<const std::byte> payload,
    const AuthenticatedConnection& connection,
    CoreService& core,
    spatial::domain::Uuid core_instance_id,
    std::uint64_t response_request_id) {
    if (core_instance_id.is_nil() || response_request_id == 0U) {
        return processor_failure(
            CommandProcessorErrorCode::invalid_configuration,
            "command processor requires a non-nil Core instance and nonzero response request id");
    }

    auto decoded = spatial::protocol::decode_transform_commit_request(payload);
    if (!decoded.has_value()) {
        return processor_failure(
            CommandProcessorErrorCode::request_decode_failed,
            "transform command decode failed: " + decoded.error().message);
    }
    const auto& request = decoded.value();

    if (!connection.authenticated || connection.instance_id != request.envelope.sender_instance_id ||
        connection.core_session_epoch != request.envelope.core_session_epoch) {
        return encode_failure(
            request,
            core,
            core_instance_id,
            response_request_id,
            {"UNAUTHORIZED_COMMAND", false, "The connection identity does not match the command envelope."});
    }

    CapturingDelivery delivery;
    const CommitSurfaceTransformCommand command{
        .command_id = request.command_id,
        .surface_id = request.surface_id,
        .transform = request.transform,
        .expected_revision = request.expected_revision,
    };
    const auto committed = core.handle_commit_surface_transform(connection, command, delivery);
    if (!committed.has_value()) {
        return encode_failure(
            request,
            core,
            core_instance_id,
            response_request_id,
            map_core_error(committed.error().code));
    }

    if (!delivery.acknowledged() || delivery.acknowledgement().command_id != request.command_id ||
        delivery.acknowledgement().entity_id != request.surface_id ||
        delivery.acknowledgement().applied_revision != committed.value().applied_revision) {
        return processor_failure(
            CommandProcessorErrorCode::canonical_state_failure,
            "Core acknowledgement did not match the committed transform command");
    }

    const auto canonical = core.canonical_surface_state(request.surface_id);
    if (!canonical.has_value()) {
        return processor_failure(
            CommandProcessorErrorCode::canonical_state_failure,
            "committed surface was absent from canonical Core state");
    }

    const spatial::protocol::TransformCommitSuccess response{
        .envelope = {
            .request_id = response_request_id,
            .correlation_id = request.envelope.request_id,
            .sender_instance_id = core_instance_id,
            .core_session_epoch = request.envelope.core_session_epoch,
            .state_revision = committed.value().applied_revision,
        },
        .command_id = committed.value().command_id,
        .entity_id = committed.value().entity_id,
        .applied_revision = committed.value().applied_revision,
        .transform_revision = canonical.value().transform_revision,
        .canonical_transform = canonical.value().transform,
        .deduplicated = committed.value().deduplicated,
    };
    auto encoded = spatial::protocol::encode_transform_commit_success(response);
    if (!encoded.has_value()) {
        return processor_failure(
            CommandProcessorErrorCode::response_encode_failed,
            "failed to encode transform success response: " + encoded.error().message);
    }
    return CommandProcessorResult::success(std::move(encoded.value()));
}

}  // namespace spatial::service
