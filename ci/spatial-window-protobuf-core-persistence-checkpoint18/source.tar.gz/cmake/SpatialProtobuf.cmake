include_guard(GLOBAL)

find_package(Python3 REQUIRED COMPONENTS Interpreter)

set(SPATIAL_PROTO_ROOT "${PROJECT_SOURCE_DIR}/contracts/proto/spatial/v1")
set(SPATIAL_PROTO_IMPORT_ROOT "${PROJECT_SOURCE_DIR}/contracts/proto")
set(SPATIAL_PROTO_GENERATED_ROOT "${PROJECT_BINARY_DIR}/generated/protobuf")
set(SPATIAL_PROTO_RELATIVE_FILES
  spatial/v1/common.proto
  spatial/v1/errors.proto
  spatial/v1/state.proto
  spatial/v1/commands.proto
  spatial/v1/events.proto
  spatial/v1/handshake.proto
  spatial/v1/plugins.proto
)

add_custom_target(spatial_contract_schema_check
  COMMAND "${Python3_EXECUTABLE}"
    "${PROJECT_SOURCE_DIR}/tools/contract_validator/validate_contracts.py"
    "${SPATIAL_PROTO_ROOT}"
  WORKING_DIRECTORY "${PROJECT_SOURCE_DIR}"
  VERBATIM
)
add_test(
  NAME spatial_contract_schema_check
  COMMAND "${Python3_EXECUTABLE}"
    "${PROJECT_SOURCE_DIR}/tools/contract_validator/validate_contracts.py"
    "${SPATIAL_PROTO_ROOT}"
)
set_tests_properties(spatial_contract_schema_check PROPERTIES
  WORKING_DIRECTORY "${PROJECT_SOURCE_DIR}"
)

find_package(Protobuf CONFIG QUIET)
if(NOT TARGET protobuf::libprotobuf AND NOT TARGET Protobuf::libprotobuf)
  find_package(Protobuf REQUIRED)
endif()

if(TARGET protobuf::libprotobuf)
  set(SPATIAL_PROTOBUF_LIBRARY_TARGET protobuf::libprotobuf)
elseif(TARGET Protobuf::libprotobuf)
  set(SPATIAL_PROTOBUF_LIBRARY_TARGET Protobuf::libprotobuf)
else()
  message(FATAL_ERROR "Protobuf package did not provide a libprotobuf target")
endif()

if(TARGET protobuf::protoc)
  set(SPATIAL_PROTOC_COMMAND "$<TARGET_FILE:protobuf::protoc>")
  set(SPATIAL_PROTOC_DEPENDENCY protobuf::protoc)
elseif(TARGET Protobuf::protoc)
  set(SPATIAL_PROTOC_COMMAND "$<TARGET_FILE:Protobuf::protoc>")
  set(SPATIAL_PROTOC_DEPENDENCY Protobuf::protoc)
elseif(Protobuf_PROTOC_EXECUTABLE)
  set(SPATIAL_PROTOC_COMMAND "${Protobuf_PROTOC_EXECUTABLE}")
  set(SPATIAL_PROTOC_DEPENDENCY "${Protobuf_PROTOC_EXECUTABLE}")
else()
  message(FATAL_ERROR "Protobuf package did not provide protoc")
endif()

set(SPATIAL_PROTO_FILES)
set(SPATIAL_PROTO_GENERATED_SOURCES)
set(SPATIAL_PROTO_GENERATED_HEADERS)
foreach(relative_path IN LISTS SPATIAL_PROTO_RELATIVE_FILES)
  list(APPEND SPATIAL_PROTO_FILES "${SPATIAL_PROTO_IMPORT_ROOT}/${relative_path}")
  string(REGEX REPLACE "\\.proto$" ".pb.cc" generated_source "${relative_path}")
  string(REGEX REPLACE "\\.proto$" ".pb.h" generated_header "${relative_path}")
  list(APPEND SPATIAL_PROTO_GENERATED_SOURCES "${SPATIAL_PROTO_GENERATED_ROOT}/${generated_source}")
  list(APPEND SPATIAL_PROTO_GENERATED_HEADERS "${SPATIAL_PROTO_GENERATED_ROOT}/${generated_header}")
endforeach()

add_custom_command(
  OUTPUT
    ${SPATIAL_PROTO_GENERATED_SOURCES}
    ${SPATIAL_PROTO_GENERATED_HEADERS}
  COMMAND "${CMAKE_COMMAND}" -E make_directory "${SPATIAL_PROTO_GENERATED_ROOT}"
  COMMAND "${SPATIAL_PROTOC_COMMAND}"
    "--proto_path=${SPATIAL_PROTO_IMPORT_ROOT}"
    "--cpp_out=${SPATIAL_PROTO_GENERATED_ROOT}"
    ${SPATIAL_PROTO_FILES}
  DEPENDS
    ${SPATIAL_PROTO_FILES}
    ${SPATIAL_PROTOC_DEPENDENCY}
  COMMENT "Generating spatial.v1 C++ Protocol Buffer bindings"
  VERBATIM
)
set_source_files_properties(
  ${SPATIAL_PROTO_GENERATED_SOURCES}
  ${SPATIAL_PROTO_GENERATED_HEADERS}
  PROPERTIES GENERATED TRUE
)

add_library(spatial_protocol_generated STATIC
  ${SPATIAL_PROTO_GENERATED_SOURCES}
  ${SPATIAL_PROTO_GENERATED_HEADERS}
)
target_include_directories(spatial_protocol_generated SYSTEM PUBLIC
  "$<BUILD_INTERFACE:${SPATIAL_PROTO_GENERATED_ROOT}>"
)
target_link_libraries(spatial_protocol_generated PUBLIC
  ${SPATIAL_PROTOBUF_LIBRARY_TARGET}
  spatial_project_options
)

add_library(spatial_contracts INTERFACE)
target_link_libraries(spatial_contracts INTERFACE spatial_protocol_generated)
target_include_directories(spatial_contracts SYSTEM INTERFACE
  "$<BUILD_INTERFACE:${SPATIAL_PROTO_GENERATED_ROOT}>"
)
